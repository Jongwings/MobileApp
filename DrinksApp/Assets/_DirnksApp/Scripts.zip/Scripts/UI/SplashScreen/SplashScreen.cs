﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Q.Utils;
using System.Collections.Generic;
using Newtonsoft.Json;
public class SplashScreen : MonoBehaviour {

//	public Button signInButton;
//	public Button signUpButton;
//	public Button emailLoginButton;
//
//
//	public GameObject buttonPanel;
//	public SignInUpPanel signInUpPanel;
//
//	public SignInPanel signInPanel;
	public SignUpHandler signUpHandler;
	public TryPanel tryPanel;
	public Button tryModeButton;
	public Button facebookLogInButton;
	public Button googlePlusButton;
//	public Button emailSignInButton;
//	public Button emailSignUPButton;
//
//	public Button SkipLoginButton;

	// Email login
	public Text emailId;
	public Text password;

	[Header("InputField")]
	public InputField emailSignInField;
	public InputField passwordSignInField;

	private string m_signText;
	private string m_passwordText;

    void Awake ()
    {
    }

	// Use this for initialization
	void Start () {

		//signInPanel.gameObject.SetActive (false);
		tryPanel.gameObject.SetActive (false);
		signUpHandler.gameObject.SetActive (false);
//		tryModeButton.onClick.AddListener (OnClickTryModeButton);
		facebookLogInButton.onClick.AddListener (OnClickFacebookLogInButton);
		googlePlusButton.onClick.AddListener (OnClickGooglePlusLogInButton);
		//emailSignInButton.onClick.AddListener (OnClickEmailSignInButton);

		emailSignInField.onEndEdit.AddListener (OnEndEditEmail);
		passwordSignInField.onEndEdit.AddListener (OnEndEditPassword);
	}

	void OnClickTryModeButton ()
	{
		tryPanel.gameObject.SetActive (true);
	}

	void OnClickFacebookLogInButton ()
	{
		GenericAudioManager.PlayFX (GenericAudioManager.SFXSounds.Button_Click_1);
		ConnectionHandler.Instance.LoginFacebook();
	}

	void OnClickGooglePlusLogInButton ()
	{
		GenericAudioManager.PlayFX (GenericAudioManager.SFXSounds.Button_Click_1);
		ConnectionHandler.Instance.LoginGooglePlus();
	}

	public void OnClickEmailSignInButton ()
	{
//		GenericAudioManager.PlayFX (GenericAudioManager.SFXSounds.Button_Click_1);
//		signInPanel.gameObject.SetActive (true);
		Debug.Log("Email Sign in ------->"+emailId.text); 
		//UserLoginAPI (emailId.text, password.text);
		//UserLoginAPICalls();
		UserLoginAPICalls();
		//AppManager.Instance.EmailSighPanel.SetActive (false);
		//AppManager.Instance.MainMenuPanel.SetActive (true);
	}
	public void UserLoginAPI(string emailId , string password)
	{
		
		FitnessApi api  = new FitnessApi("",ServerResponseForLogintoServer);
		api.param("login.php?user_name",emailId);
		api.param ("password", password);
		api.get(this);
	}


	void ServerResponseForLogintoServer(IDictionary output,string text, string error,int responseCode,IDictionary inCustomData)
	{
		Debug.Log ("REsponse from server ----:" + text);
		// check for errors
		if (output != null) {
			string responseInfo = (string)output ["responseInfo"];

			switch (responseCode) {
			case 001:
				break;
			}
		}
	}

	public void UserLoginAPICalls()
	{
		string url = "http://www.jongwings.com/chivita/app/login.php?";

		WWWForm wwwForm = new WWWForm ();

		wwwForm.AddField ("user_name", "daniel");
		wwwForm.AddField ("password", "test123");
		WWW www = new WWW (url, wwwForm);
		StartCoroutine (LoginToServerCallback (www));
	}

	IEnumerator LoginToServerCallback (WWW www)
	{
		yield return www;
		if (www.error == null) {
			Debug.Log (www.text);

			AppManager.Instance.EmailSighPanel.SetActive (false);
			AppManager.Instance.IntroPanel.SetActive (true);
			Invoke("CallMainMenuPanel", 3);//this will happen after 3 seconds
		}
	}

	void CallMainMenuPanel()
	{
		AppManager.Instance.IntroPanel.SetActive (false);
		AppManager.Instance.MainMenuPanel.SetActive (true);

	}


	void OnClickSignInButton ()
	{
		GenericAudioManager.PlayFX (GenericAudioManager.SFXSounds.Button_Click_1);
		Q.Utils.QDebug.Log ("OnClickSignInButton");
		EnableSignInUpPanel (SignInUpPanel.eSignInUp.SignIn);
	}

	public void OnClickSignUpButton ()
	{
		Debug.Log("Email Sign up ------->"); 
		GenericAudioManager.PlayFX (GenericAudioManager.SFXSounds.Button_Click_1);
		Q.Utils.QDebug.Log ("OnClickSignUpButton");
		//EnableSignInUpPanel (SignInUpPanel.eSignInUp.SignUp);
		AppManager.Instance.SighUpPanel.SetActive(true);
		AppManager.Instance.EmailSighPanel.SetActive (false);

	}
	public void OnClickRegisterBackBtn()
	{
		AppManager.Instance.EmailSighPanel.SetActive (true);
		AppManager.Instance.SighUpPanel.SetActive(false);
	}

	public void OnClickSignUpConformButton()
	{
		AppManager.Instance.EmailSighPanel.SetActive (true);
		AppManager.Instance.SighUpPanel.SetActive(false);
	}

	public void OnClickSkipButton()
	{
		AppManager.Instance.EmailSighPanel.SetActive (false);
		AppManager.Instance.MainMenuPanel.SetActive (true);
	}



	void EnableSignInUpPanel (SignInUpPanel.eSignInUp state)
	{
//		buttonPanel.gameObject.SetActive (false);
//		signInUpPanel.gameObject.SetActive (true);
//		signInUpPanel.EnablePanel (state);
	}

	public void DisableSignInUpPanel ()
	{
//		buttonPanel.gameObject.SetActive (true);
//		signInUpPanel.gameObject.SetActive (false);
	}

	void OnEndEditEmail(string text)
	{
		m_signText = text;
		Debug.Log("Email id --->"+text);
	}

	void OnEndEditPassword(string text)
	{
		m_passwordText = text;
		Debug.Log("Password id --->"+text);

	}

}
