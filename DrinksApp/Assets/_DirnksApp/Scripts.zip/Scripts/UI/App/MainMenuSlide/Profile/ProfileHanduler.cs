﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ProfileHanduler : MonoBehaviour {

	public Text name;
	public Text username;
	public Text emailID;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnclickUpdateProfile()
	{
		Debug.Log ("Update Profile Button Click");
		MainMenuSlideManager.Instance.OnclickHideMainMenuSlideScreen ();
	}
}
