﻿using UnityEngine;
using System.Collections;

public class MainMenuSlideManager : MonoBehaviour {

	public GameObject homeScreenPanel;

	public GameObject profilePanel;
	public GameObject creditsPanel;
	public GameObject FavouriatesPanel;
	public GameObject LogOutPanel;

	public RectTransform MainMenuSlidePanelRectTransform;

	public static MainMenuSlideManager Instance;
	// Use this for initialization
	void Start () {
		if (Instance == null) {
			Instance = this;
		}
		profilePanel.SetActive (false);
		creditsPanel.SetActive (false);
		FavouriatesPanel.SetActive (false);
		LogOutPanel.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnclickHideMainMenuSlideScreen()
	{
		Debug.Log ("Main Menu Hide ----:");
		MainMenuSlideOnclickHide ();
		homeScreenPanel.SetActive (false);
		profilePanel.SetActive (false);
		creditsPanel.SetActive (false);
		FavouriatesPanel.SetActive (false);
		LogOutPanel.SetActive (false);
	}

	public void OnclickHome()
	{
		
		MainMenuSlideOnclickHide ();
		homeScreenPanel.SetActive (true);
		profilePanel.SetActive (false);
		creditsPanel.SetActive (false);
		FavouriatesPanel.SetActive (false);
		LogOutPanel.SetActive (false);
	}

	public void OnclickProfile()
	{
		profilePanel.SetActive (true);
		creditsPanel.SetActive (false);
		FavouriatesPanel.SetActive (false);
		LogOutPanel.SetActive (false);

		MainMenuSlideOnclickHide ();
	}

	public void OnclickFavourites()
	{
		FavouriatesPanel.SetActive (true);
		profilePanel.SetActive (false);
		creditsPanel.SetActive (false);
		LogOutPanel.SetActive (false);

		MainMenuSlideOnclickHide ();
	}

	public void OnclickCredit()
	{
		creditsPanel.SetActive (true);
		profilePanel.SetActive (false);
		FavouriatesPanel.SetActive (false);
		LogOutPanel.SetActive (false);

		MainMenuSlideOnclickHide ();
	}

	public void OnclickLogout()
	{
		LogOutPanel.SetActive (true);
		profilePanel.SetActive (false);
		creditsPanel.SetActive (false);
		FavouriatesPanel.SetActive (false);

		MainMenuSlideOnclickHide ();
	}

	public void MainMenuSlideOnclickShow()
	{
		float inch = Mathf.Sqrt((Screen.width * Screen.width) + (Screen.height * Screen.height));
		inch = inch/Screen.dpi;

		Debug.Log ("inch :" + inch);

		//MainMenuPanelManager.Instance.MainMenuSlidePanel.SetActive (true);
		if (MainMenuSlidePanelRectTransform != null) {
			Debug.Log ("MainMenuSlideOnclickShow :111");

			LeanTween.move (MainMenuSlidePanelRectTransform, new Vector3 (-500f, 0f, 0f), 1f).setDelay (.5f);
		}
	}



	public void MainMenuSlideOnclickHide()
	{
		Debug.Log ("MainLeftActionBarHide :");
		//MainLeftActionBar.anchoredPosition3D += new Vector3(200f,0f,0f);
		//LeanTween.moveX( MainLeftActionBar, .5f, 05f).setEase(LeanTweenType.easeOutExpo).setDelay(1f);
		//LeanTween.moveZ( MainLeftActionBar, MainLeftActionBar.anchoredPosition3D.z - 80f, 1.5f).setEase(LeanTweenType.punch).setDelay(2.0f);

		//LeanTween.moveX (MainLeftActionBar, 1f, .2f);
		LeanTween.move(MainMenuSlidePanelRectTransform, new Vector3(-1050f,0f,0f), 1f).setDelay(.5f);
	}

	public void OnClickOutside()
	{
		MainMenuSlideOnclickHide ();
	}

}
