﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;

public class CollectionController : MonoBehaviour {

	public class Collection
	{
		public string collection_id { get; set; }
		public string collection_name { get; set; }
		public string recipes_image { get; set; }
	}
	public class CollectionDictionary
	{
		public List<Collection> categoryList = new List<Collection> ();
		//public List<Topics> topic = new List<Topics> ();
	}

	// Use this for initialization
	void Start () {
		CollectionsAPICalls ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void CollectionsAPICalls()
	{
		string url = "http://www.jongwings.com/chivita/app/list-collection.php";

		WWWForm wwwForm = new WWWForm ();

		//		wwwForm.AddField ("user_name", "daniel");
		//		wwwForm.AddField ("password", "test123");
		WWW www = new WWW (url);
		StartCoroutine (CollectionServerCallback (www));
	}

	IEnumerator CollectionServerCallback (WWW www)
	{
		yield return www;
		if (www.error == null) {
			Debug.Log (www.text);
			CollectionDictionary newCategory = new CollectionDictionary ();
			newCategory = JsonConvert.DeserializeObject<CollectionDictionary> (GetResponseMessage (www.text));

			Debug.Log (JsonConvert.SerializeObject (newCategory));
		}
	}
	string GetResponseMessage (string serverResponse)
	{
		IDictionary response = (IDictionary)Facebook.MiniJSON.Json.Deserialize(serverResponse);
		string _response_msg = JsonConvert.SerializeObject(response[ServerConstant.RESPONSE_MSG]);

		return _response_msg;
	}
}
