﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TotalScoreItem : MonoBehaviour 
{
	public Text sportsType;
	public Image imgColor;
}