﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class SportPrefsCellsHandler : MonoBehaviour {

	public List<Toggle> togglesList = new List<Toggle> ();
}