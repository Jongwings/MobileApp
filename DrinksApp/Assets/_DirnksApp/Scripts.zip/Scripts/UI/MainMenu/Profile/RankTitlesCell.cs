﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class RankTitlesCell : MonoBehaviour 
{
	public Text rankTitle;
}
