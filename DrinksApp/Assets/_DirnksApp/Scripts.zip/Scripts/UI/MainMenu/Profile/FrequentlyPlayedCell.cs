﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class FrequentlyPlayedCell : MonoBehaviour 
{
	public Image profileImage;
	public Text name;
}
