public static class CurrentBundleVersion
{
	public static readonly string version = "1.0";
}

